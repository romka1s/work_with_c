It`s a program, which can do tree of directory

needs run:
    ./main PATH

example run: ./main ./dir - directory in ZIP


functions:

buildTree - bulid tree of directory
printTree - print on terminal tree of directory
freeTree - free memory of tree of directory
writeTreeToFile - write tree of directory to bin file (default file : Tree.bin)
giveTreeFromFile - give tree of directory from bin file (defailt file : Tree.bin)